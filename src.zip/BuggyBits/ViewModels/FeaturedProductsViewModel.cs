﻿using System.Data;

namespace BuggyBits.ViewModels
{
    public class FeaturedProductsViewModel
    {
        public DataView FeaturedProducts { get; set; }
    }
}
