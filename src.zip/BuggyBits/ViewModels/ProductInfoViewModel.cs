﻿namespace BuggyBits.ViewModels
{
    public class ProductInfoViewModel
    {
        public string ProductName { get; set; }
        public string Distributor { get; set; }
        public string ShippingInfo { get; set; }
    }
}
