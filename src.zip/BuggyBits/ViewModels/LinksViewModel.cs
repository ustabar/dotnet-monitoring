﻿using System.Collections;

namespace BuggyBits.ViewModels
{
    public class LinksViewModel
    {
        public Hashtable Links { get; set; }
    }
}
