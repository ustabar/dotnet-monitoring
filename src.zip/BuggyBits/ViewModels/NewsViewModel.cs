﻿using Microsoft.AspNetCore.Html;

namespace BuggyBits.ViewModels
{
    public class NewsViewModel
    {
        public IHtmlContent News { get; set; }
    }
}
