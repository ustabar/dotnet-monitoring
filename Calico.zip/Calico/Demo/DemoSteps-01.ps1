# Reference
# https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/kubernetes-demo
#
# PortForwarding
# https://kubernetes.io/docs/tasks/access-application-cluster/port-forward-access-application-cluster/

# 1 : Create the frontend, backend, client, and management-ui apps.

kubectl create -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/manifests/00-namespace.yaml
kubectl create -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/manifests/01-management-ui.yaml
kubectl create -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/manifests/02-backend.yaml
kubectl create -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/manifests/03-frontend.yaml
kubectl create -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/manifests/04-client.yaml

kubectl get pods --all-namespaces
kubectl get services -A
kubectl get services -n management-ui
kubectl port-forward -n management-ui services/management-ui 9001

# 2 : Enable isolation

kubectl create -n stars -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/policies/default-deny.yaml
kubectl create -n client -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/policies/default-deny.yaml

kubectl get services -n management-ui
kubectl port-forward -n management-ui services/management-ui 9001

# 3 : Allow the UI to access the services using network policy objects

kubectl create -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/policies/allow-ui.yaml
kubectl create -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/policies/allow-ui-client.yaml

kubectl get services -n management-ui
kubectl port-forward -n management-ui services/management-ui 9001

# 4 : Create the backend-policy.yaml file to allow traffic from the frontend to the backend

kubectl create -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/policies/backend-policy.yaml

kubectl get services -n management-ui
kubectl port-forward -n management-ui services/management-ui 9001

# 5 : Expose the frontend service to the client namespace

kubectl create -f https://docs.projectcalico.org/security/tutorials/kubernetes-policy-demo/policies/frontend-policy.yaml

kubectl get services -n management-ui
kubectl port-forward -n management-ui services/management-ui 9001

# 6 : (Optional) Clean up the demo environment

kubectl delete ns client stars management-ui

# 7 : Test the application

kubectl port-forward -n management-ui services/management-ui 9001

# browse : 127.0.0.1:64354