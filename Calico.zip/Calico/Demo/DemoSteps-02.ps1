# Reference
# https://docs.projectcalico.org/security/tutorials/kubernetes-policy-advanced

# 1. Create the namespace and nginx service
kubectl create ns advanced-policy-demo
kubectl create deployment --namespace=advanced-policy-demo nginx --image=nginx
kubectl expose --namespace=advanced-policy-demo deployment nginx --port=80

# Verify access - allowed all ingress and egress
# Open up a second shell session which has kubectl connectivity to the Kubernetes cluster and 
# create a busybox pod to test policy access. 
# This pod will be used throughout this tutorial to test policy access.
kubectl run --namespace=advanced-policy-demo access --rm -ti --image busybox /bin/sh
wget -q --timeout=5 nginx -O -
wget -q --timeout=5 google.com -O -

# 2. Deny all ingress traffic
# Enable ingress isolation on the namespace by deploying a default deny all ingress traffic policy.
kubectl apply -f Demo-02-02.yaml

# Verify access - allowed all ingress and egress
wget -q --timeout=5 nginx -O -
wget -q --timeout=5 google.com -O -

# 3. Allow ingress traffic to Nginx
# Run the following to create a NetworkPolicy which allows traffic to nginx pods 
# from any pods in the advanced-policy-demo namespace.
kubectl apply -f Demo-02-03.yaml

# Verify access - allowed all ingress and egress
wget -q --timeout=5 nginx -O -

# 4. Deny all egress traffic
# Enable egress isolation on the namespace by deploying a default deny all egress traffic policy.
kubectl apply -f Demo-02-04.yaml

# Verify access - allowed all ingress and egress
nslookup nginx
wget -q --timeout=5 google.com -O -

# 5. Allow DNS egress traffic
# Run the following to create a label of name: kube-system on the kube-system namespace 
# and a NetworkPolicy which allows DNS egress traffic from any pods in the advanced-policy-demo 
# namespace to the kube-system namespace.
kubectl label namespace kube-system name=kube-system
kubectl apply -f Demo-02-05.yaml

# Verify access - allowed all ingress and egress
nslookup nginx
nslookup google.com

# 6. Allow egress traffic to nginx
# Run the following to create a NetworkPolicy which allows egress traffic 
# from any pods in the advanced-policy-demo namespace to pods with labels matching app: 
# nginx in the same namespace.
kubectl apply -f Demo-02-06.yaml

# Verify access - allowed all ingress and egress
wget -q --timeout=5 nginx -O -
wget -q --timeout=5 google.com -O -

# 7. Clean up namespace
# You can clean up after this tutorial by deleting the advanced policy demo namespace.
kubectl delete ns advanced-policy-demo